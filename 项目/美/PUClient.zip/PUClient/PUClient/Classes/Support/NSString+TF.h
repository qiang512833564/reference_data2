//
//  NSString+TF.h
//  test
//
//  Created by Tengfei on 15/5/8.
//  Copyright (c) 2015年 tengfei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (TF)
/**
 *  @return 32位MD5加密结果
 */
- (NSString *)MD5;
@end
