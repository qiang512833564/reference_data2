//
//  BoundThildVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/21.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseViewController.h"

@interface BoundThildVC : BaseViewController
@property (nonatomic,retain)NSDictionary * thirdInfo;
@end
