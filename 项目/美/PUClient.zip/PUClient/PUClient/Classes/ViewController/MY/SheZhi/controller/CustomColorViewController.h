//
//  CustomColorViewController.h
//  PUClient
//
//  Created by lizhongqiang on 15/7/30.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseViewController.h"

@interface CustomColorViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
