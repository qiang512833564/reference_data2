//
//  CalendarViewController.h
//  PUClient
//
//  Created by lizhongqiang on 15/7/29.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FSCalendar.h"
#import "BaseViewController.h"

@interface CalendarViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UILabel *HeadDateLabel;
@property (weak, nonatomic) IBOutlet FSCalendar *calendar;

@end
