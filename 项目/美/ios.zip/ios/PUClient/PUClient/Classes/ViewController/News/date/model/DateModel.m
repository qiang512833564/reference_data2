//
//  DateModel.m
//  PUClient
//
//  Created by RRLhy on 15/8/12.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "DateModel.h"

@implementation DateModel

- (id)init
{
    self = [super init];
    if (self) {
    
    }return self;
}

@end
