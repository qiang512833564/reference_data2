//
//  BoundNextVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/21.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseWhiteViewController.h"

@interface BoundNextVC : BaseWhiteViewController
@property(nonatomic,assign)BOOL isOld;
@property (nonatomic,retain)NSDictionary * userInfo;
@end
