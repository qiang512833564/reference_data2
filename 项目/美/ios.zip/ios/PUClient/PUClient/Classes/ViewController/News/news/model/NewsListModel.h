//
//  NewsListModel.h
//  PUClient
//
//  Created by RRLhy on 15/8/12.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "NewRingListModel.h"

@interface NewsListModel : NewRingListModel

@end
