//
//  NewImageModel.m
//  PUClient
//
//  Created by RRLhy on 15/8/17.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "NewImageModel.h"

@implementation NewImageModel

@end
