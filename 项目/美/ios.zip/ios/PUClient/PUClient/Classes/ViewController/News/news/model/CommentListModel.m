//
//  CommentListModel.m
//  PUClient
//
//  Created by RRLhy on 15/8/13.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "CommentListModel.h"

@implementation CommentListModel

+ (NSDictionary *)objectClassInArray{
    
    return @{ @"results" : @"CommentModel"};
}

@end
