//
//  PsdEmailVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/21.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseWhiteViewController.h"

@interface PsdEmailVC : BaseWhiteViewController
@property (nonatomic,assign)BOOL isEmail;
@property (nonatomic,copy)NSString * phone;
@property (nonatomic,copy)NSString * code;
@end
