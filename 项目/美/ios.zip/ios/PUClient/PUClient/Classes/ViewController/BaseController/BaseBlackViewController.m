//
//  BaseBlackViewController.m
//  PUClient
//
//  Created by RRLhy on 15/8/9.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseBlackViewController.h"

@interface BaseBlackViewController ()

@end

@implementation BaseBlackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

//    self.navImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, Main_Screen_Width, kStatusBarHeight + kTopBarHeight)];
//    self.navImage.image = [UIImage stretchImageWithName:@"nav_bg_black"];
//    self.navImage.userInteractionEnabled = YES;
//    [self.view addSubview:self.navImage];
//    
//    self.leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [self.leftBtn setFrame:CGRectMake(0, 20, 44, 44)];
//    [self.leftBtn setImage:[UIImage imageNamed:@"nav_back_me_h"] forState:UIControlStateNormal];
//    [self.leftBtn addTarget:self action:@selector(popViewController) forControlEvents:UIControlEventTouchUpInside];
//    [self.leftBtn.imageView setContentMode:UIViewContentModeScaleAspectFit];
//    [self.navImage addSubview:self.leftBtn];
//    
//    self.rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [self.rightBtn setFrame:CGRectMake((Main_Screen_Width - 54), 20, 44, 44)];
//    [self.rightBtn setImage:[UIImage imageNamed:@"nav_back_me_h"] forState:UIControlStateNormal];
//    [self.rightBtn addTarget:self action:@selector(rightBtnClick) forControlEvents:UIControlEventTouchUpInside];
//    [self.rightBtn.imageView setContentMode:UIViewContentModeScaleAspectFit];
//    [self.rightBtn setHidden:YES];
//    [self.rightBtn.titleLabel setFont:BOLDSYSTEMFONT(14)];
//    [self.navImage addSubview:self.rightBtn];
//    
//    
//    self.titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(80, 20, (Main_Screen_Width - 160), 44)];
//    self.titleLabel.font = BOLDSYSTEMFONT(16);
//    self.titleLabel.textAlignment = NSTextAlignmentCenter;
//    self.titleLabel.textColor = [UIColor whiteColor];
//    [self.navImage addSubview:self.titleLabel];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
