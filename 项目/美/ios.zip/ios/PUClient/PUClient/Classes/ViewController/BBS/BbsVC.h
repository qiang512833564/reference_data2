//
//  BbsVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/22.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseWhiteViewController.h"

@interface BbsVC : BaseWhiteViewController

@end
