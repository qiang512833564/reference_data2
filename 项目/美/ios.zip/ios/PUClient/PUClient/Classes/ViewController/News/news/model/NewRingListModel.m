//
//  NewRingListModel.m
//  PUClient
//
//  Created by RRLhy on 15/8/12.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "NewRingListModel.h"

@implementation NewRingListModel

+ (NSDictionary *)objectClassInArray{
    
    return @{ @"results" : @"NewRingModel"};
}

@end
