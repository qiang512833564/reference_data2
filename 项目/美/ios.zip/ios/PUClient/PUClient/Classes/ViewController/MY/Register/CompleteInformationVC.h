//
//  CompleteInformationVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/20.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseWhiteViewController.h"

@interface CompleteInformationVC : BaseWhiteViewController
@property (nonatomic,copy)NSString * mobile;//手机号

@property (nonatomic,copy)NSString * code;


@end
