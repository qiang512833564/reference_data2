//
//  NewsListModel.m
//  PUClient
//
//  Created by RRLhy on 15/8/12.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "NewsListModel.h"

@implementation NewsListModel

+ (NSDictionary *)objectClassInArray{
    
    return @{ @"results" : @"NewsIntroModel"};
}

@end
