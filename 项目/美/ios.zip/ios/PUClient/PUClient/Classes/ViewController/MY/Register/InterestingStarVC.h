//
//  InterestingStarVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/20.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseWhiteViewController.h"

@interface InterestingStarVC : BaseWhiteViewController
@property (nonatomic)NSString * seriersIdString;
@end
