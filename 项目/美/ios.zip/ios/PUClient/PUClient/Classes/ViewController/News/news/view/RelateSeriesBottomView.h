//
//  RelateSeriesBottomView.h
//  PUClient
//
//  Created by RRLhy on 15/8/13.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RelateSeriesBottomView : UIView

@end
