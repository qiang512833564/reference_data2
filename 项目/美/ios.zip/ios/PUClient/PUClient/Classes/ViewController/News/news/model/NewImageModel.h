//
//  NewImageModel.h
//  PUClient
//
//  Created by RRLhy on 15/8/17.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewImageModel : NSObject

@property (nonatomic,copy)NSString * content;

@property (nonatomic,copy)NSString * insertTitle;

@property (nonatomic,copy)NSString * insertUrl;

@end
