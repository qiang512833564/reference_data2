//
//  UserInformationVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/30.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseTableViewController.h"

@interface UserInformationVC : BaseTableViewController

@end
