//
//  BoundThildVC.h
//  PUClient
//
//  Created by RRLhy on 15/7/21.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseWhiteViewController.h"

@interface BoundThildVC : BaseWhiteViewController
@property (nonatomic,retain)NSDictionary * thirdInfo;
@end
