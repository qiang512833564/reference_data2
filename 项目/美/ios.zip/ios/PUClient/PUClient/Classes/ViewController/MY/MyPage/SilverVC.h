//
//  SilverVC.h
//  PUClient
//
//  Created by RRLhy on 15/8/3.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "BaseTableViewController.h"

@interface SilverVC : BaseTableViewController

@end
