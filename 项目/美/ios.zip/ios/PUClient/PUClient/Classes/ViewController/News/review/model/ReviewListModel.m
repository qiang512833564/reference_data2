//
//  ReviewListModel.m
//  PUClient
//
//  Created by RRLhy on 15/8/17.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "ReviewListModel.h"

@implementation ReviewListModel


+ (NSDictionary *)objectClassInArray{
    
    return @{ @"results" : @"ReviewModel"};
}

@end
