//
//  Global.h
//  ClearCache
//
//  Created by LXJ on 15/7/20.
//  Copyright (c) 2015年 GOME. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClearCache : NSObject

+ (NSString*)cathSize;

+ (void)clearCache;

+ (NSString *)getFilePathWithCache;

@end
