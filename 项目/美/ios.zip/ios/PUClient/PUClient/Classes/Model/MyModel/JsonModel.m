//
//  JsonModel.m
//  PUClient
//
//  Created by RRLhy on 15/7/27.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "JsonModel.h"

@implementation JsonModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

//- (void)setValue:(id)value forKey:(NSString *)key
//{
//    if ([key isEqualToString:@"code"]) {
//        if ([value isEqualToString:@"0000"]) {
//            _code = [value integerValue];
//        }
//    }
//}
@end
