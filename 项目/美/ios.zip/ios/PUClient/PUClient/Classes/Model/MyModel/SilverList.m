//
//  SilverList.m
//  PUClient
//
//  Created by RRLhy on 15/8/5.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "SilverList.h"

@implementation SilverList

+ (NSDictionary *)objectClassInArray{
    
    return @{ @"recordList" : @"Silver"};
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end
