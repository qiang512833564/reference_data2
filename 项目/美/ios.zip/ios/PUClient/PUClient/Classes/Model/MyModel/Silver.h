//
//  Silver.h
//  PUClient
//
//  Created by RRLhy on 15/8/5.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Silver : NSObject

@property (nonatomic,copy)NSString * createTimeStr;

@property (nonatomic,copy)NSString * type;

@property (nonatomic,copy)NSString * silverCount;

@end
