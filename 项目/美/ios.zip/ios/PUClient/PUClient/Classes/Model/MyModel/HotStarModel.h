//
//  HotStarModel.h
//  PUClient
//
//  Created by RRLhy on 15/7/28.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <Foundation/Foundation.h>
/*name: "444",
 groupId: 444,
 headImgUrl: "444",
 roleName: "444",
 createTimeStr: "",
 createTime: null,
 updateTime: null,
 id: 1*/
@interface HotStarModel : NSObject

@property (nonatomic,copy)NSString * name;

@property (nonatomic,copy)NSString * groupId;

@property (nonatomic,copy)NSString * headImgUrl;

@property (nonatomic,copy)NSString * roleName;

@property (nonatomic,copy)NSString * createTimeStr;

@property (nonatomic,copy)NSString * Id;












@end
