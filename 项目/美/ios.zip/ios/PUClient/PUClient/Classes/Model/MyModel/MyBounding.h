//
//  MyBounding.h
//  PUClient
//
//  Created by RRLhy on 15/8/6.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyBounding : NSObject

@property (nonatomic,copy)NSString * mobile;


@property (nonatomic,copy)NSString * qq;


@property (nonatomic,copy)NSString * sina;


@property (nonatomic,copy)NSString * wxsession;


@end
