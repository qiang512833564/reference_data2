//
//  RrmjUser.m
//  PUClient
//
//  Created by RRLhy on 15/7/22.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "RrmjUser.h"

@implementation RrmjUser

// NSCoding实现
MJCodingImplementation

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

/**
 *  字典和模型不对应，手动写对应关系
 */
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"Id" : @"id"};
}

@end
