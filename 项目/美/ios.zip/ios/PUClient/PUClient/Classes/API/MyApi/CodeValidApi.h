//
//  CodeValidApi.h
//  PUClient
//
//  Created by RRLhy on 15/7/28.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "YTKBaseRequest.h"

@interface CodeValidApi : YTKBaseRequest
/**
 *  注册流程 手机获取验证码
 *
 *  @param phone 手机号
 *
 *  @return 手机注册 api
 */
- (id)initWithUserPhone:(NSString*)phone;

@end
