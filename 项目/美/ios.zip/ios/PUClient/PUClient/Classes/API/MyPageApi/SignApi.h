//
//  SignApi.h
//  PUClient
//
//  Created by RRLhy on 15/8/5.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "YTKRequest.h"

@interface SignApi : YTKRequest

/**
 *  用户签到api
 *
 *  @param token 登陆的token
 *
 *  @return 签到api
 */
- (id)initWithUserToken:(NSString*)token;

@end
