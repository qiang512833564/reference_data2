//
//  Bound3rdApi.h
//  PUClient
//
//  Created by RRLhy on 15/8/4.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "YTKBaseRequest.h"

@interface Bound3rdApi : YTKBaseRequest
/**
 *  查看我现在的绑定的情况
 *
 *  @param userToken 用户token
 *
 *  @return 返回api
 */
- (id)initWithUserToken:(NSString*)userToken;

@end
