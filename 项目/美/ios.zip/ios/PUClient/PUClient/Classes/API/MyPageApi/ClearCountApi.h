//
//  ClearCountApi.h
//  PUClient
//
//  Created by RRLhy on 15/8/4.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "YTKRequest.h"

@interface ClearCountApi : YTKRequest
/**
 *  接触绑定
 *
 *  @param token 用户token
 *  @param name  用户绑定的第三方平台账号
 *
 *  @return 返回api
 */
- (id)initWithUserToken:(NSString*)token platName:(NSString*)name;

@end
