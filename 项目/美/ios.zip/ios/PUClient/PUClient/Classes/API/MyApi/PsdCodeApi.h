//
//  PsdCodeApi.h
//  PUClient
//
//  Created by RRLhy on 15/7/28.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "YTKBaseRequest.h"

@interface PsdCodeApi : YTKBaseRequest
/**
 *  通过手机号，找回密码
 *
 *  @param phone 手机号
 *
 *  @return 手机找回密码api
 */
- (id)initWithUserPhone:(NSString*)phone;

@end
