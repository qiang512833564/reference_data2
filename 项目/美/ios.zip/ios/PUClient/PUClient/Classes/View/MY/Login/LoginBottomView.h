//
//  LoginBottomView.h
//  PUClient
//
//  Created by RRLhy on 15/7/19.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^ThirdIndexBlock)(NSInteger index);
@interface LoginBottomView : UIView
@property (nonatomic,copy)ThirdIndexBlock thirdIndex;
- (instancetype)initWithFrame:(CGRect)frame item:(NSArray*)itemArray;
@end
