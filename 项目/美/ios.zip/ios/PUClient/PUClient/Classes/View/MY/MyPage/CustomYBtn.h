//
//  CustomYBtn.h
//  PUClient
//
//  Created by RRLhy on 15/7/29.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomYBtn : UIButton

@end
