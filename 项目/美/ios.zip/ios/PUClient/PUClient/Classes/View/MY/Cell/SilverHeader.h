//
//  SilverHeader.h
//  PUClient
//
//  Created by RRLhy on 15/8/3.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SilverHeader : UIView
@property (nonatomic,retain)UIImageView * silverImage;

@property (nonatomic,retain)UILabel * numLabel;

- (void)upDateSilverCount:(NSString*)count;

@end
