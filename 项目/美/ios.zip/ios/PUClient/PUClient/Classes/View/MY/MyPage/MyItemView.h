//
//  MyItemView.h
//  PUClient
//
//  Created by RRLhy on 15/7/29.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^MyItemBlock) (NSInteger index);

@interface MyItemView : UIView

@property (nonatomic,copy)MyItemBlock selectBlock;

@end
