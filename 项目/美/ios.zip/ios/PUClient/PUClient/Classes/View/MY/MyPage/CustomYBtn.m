//
//  CustomYBtn.m
//  PUClient
//
//  Created by RRLhy on 15/7/29.
//  Copyright (c) 2015年 RRLhy. All rights reserved.
//

#import "CustomYBtn.h"

@implementation CustomYBtn

- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(0, 10, contentRect.size.width, contentRect.size.height*1.5/3 - 10);
}

- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(0, contentRect.size.height * 2/3, contentRect.size.width, contentRect.size.height /3 - 10);
}

@end
